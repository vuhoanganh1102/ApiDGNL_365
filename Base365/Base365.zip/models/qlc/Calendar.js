// const mongoose = require('mongoose');
// const Schema = mongoose.Schema;

// const CC365_CycleSchema = new Schema({
//     cy_id: {
//         type: Number,
//         require: true
//     },
//     com_id: {
//         type: Number,
//         require: true
//     },
//     cy_name: {
//         type: String,
//         default: ""
//     },
//     apply_month: {
//         type: String,
//         default: ""
//     },
//     cy_detail: {
//         type: String,
//         default: ""
//     },
//     status: {
//         type: Number,
//         default: 1
//     },
//     is_personal: {
//         type: Number,
//         default: 0
//     }
// }, {
//     collection: 'CC365_Cycle',
//     versionKey: false,
//     timestamp: true
// });

// module.exports = mongoose.model("CC365_Cycle", CC365_CycleSchema);